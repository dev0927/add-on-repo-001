import re,base64


def get_src(word, txt):
    regexpstr = word + "'?[ :=]+['\"]?([^ ',\"]+)" 
    src = re.compile(regexpstr).findall(txt)[0]
    return src

def unescape(src):
    return re.sub(r'%([a-fA-F0-9]{4}|[a-fA-F0-9]{2})', lambda m: chr(int(m.group(1), 16)), src)
def encode_tuple(name, url): 
   print("name='" +  name.encode('base64', 'strict').replace('\n', '') + "'")
   print("url = '" + url.encode('base64', 'strict').replace('\n', '') + "'")
   print("config_channel(name, url)")
def config_channel(encoded_name,encoded_url):
	name = encoded_name.decode('base64')
	print(name)
	url = encoded_url.decode('base64')
	print(url)
	
name="VIET-SEX"
url='rtmp://64.62.143.5/live/do%20not%20steal%20my-Stream2'
encode_tuple(name, url)
name = 'FM 105!'
url = 'rtmp://fms.105.net:1935/live playpath=105Test1 live=true'
encode_tuple(name, url)
name = 'BRAZZERS EUROPE'
url = 'http://212.220.30.219/hls/CH_BRAZZERSTV/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'PLAYBOY'
url = 'http://212.220.30.219/hls/CH_PLAYBOY/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'XXL'
url = 'http://212.220.30.219/hls/CH_XXL/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'BLUE HUSTLER'
url = 'http://212.220.30.219/hls/CH_BLUEHUSTLER/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'RUSSIAN NIGHT'
url = 'http://212.220.30.219/hls/CH_RUSSIANNIGHT/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name ='OLALA'
url = 'http://212.220.30.219/hls/CH_OLALA/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name ='Miami TV'
url ='http://k4.usastreams.com:1935/miamitv/smil:miamitv/playlist.m3u8'
encode_tuple(name, url)
name ='PassieXXX'
url ='rtmp://178.33.126.213/leved/ playPath=passielivestream'
encode_tuple(name, url)
name ='Private'
url ='http://178.33.126.213:1935/leved/privateCom/.m3u8'
encode_tuple(name, url)
