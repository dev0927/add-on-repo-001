import urllib,urllib2, re,base64, time, math, js2py
from HTMLParser import HTMLParser

def get_src(word, txt):
    regexpstr = word + "'?[ :=]+['\"]?([^ ',\"]+)" 
    src = re.compile(regexpstr).findall(txt)[0]
    return src

def unescape(src, byteSize=32):
    if(byteSize == 32):
        return re.sub(r'%([a-fA-F0-9]{2})', lambda m: chr(int(m.group(1), 16)), src)
    else:
        return re.sub(r'%([a-fA-F0-9]{4}|[a-fA-F0-9]{2})', lambda m: chr(int(m.group(1), 16)), src)

class NoRedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        return infourl
    http_error_300 = http_error_302
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302

def open_url(url):
    opener = urllib2.build_opener(NoRedirectHandler()) 
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0')
    req.add_header("Connection", "keep-alive")
    req.add_header("Referer", url)
    #open initial page
    response = opener.open(req)
    return response.read()
    
def test_js_convert(js_text):
    
    #val =  js2py.eval_js("function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('15=\"c://1f.1c.9/1A/1C/1s/1q.1z/1o.1l\";7 j=(b.a!=b.o.a)?g.q:g.a.14;7 m=(b.a!=b.o.a)?g.q:b.r.a.14;7 11=(b.a!=b.o.a)?g.q:g.1h;7 B={1V:1Z(15),23:\"21\",22:\"#1R\",1I:8,1J:8,1H:\"1E\",x:\"v\",1K:5,1L:\"c://e.9/h/f/L.1U\",1N:\"c://e.9/h/f/1M.f\",1O:1,1P:10,1Q:3,1F:-1,1G:-1,1S:\"24\",25:\"z\",20:d,1D:d,1T:8,1W:8,1Y:8,1X:8,26:8,1B:8,1i:8,1j:10,1k:5,1m:\"1g\",1n:d};7 D={1b:8,1e:\"1y\",1x:\"#1v\",1p:\"1u\"};7 C={16:\"2\"};1t.1r(\"c://e.9/h/f/1w.f\",\"2\",\"F%\",\"F%\",\"10.3\",1d,B,D,C);7 2;7 l=d;7 s=0.1;7 1a=4;7 18=10;k z(J,V,2L){2G(V){6\"2F\":2=g.2B(J);2.p(\"2A\",\"19\");2.p(\"2C\",\"E\");2.p(\"P\",\"O\");2.p(\"P\",\"M\");i;6\"2D\":6\"L\":l=d;2.n(s);i;6\"2E\":2.2M(\"2N\");l=8;i;6\"2W\":6\"t\":6\"2V\":6\"2X\":2.n(s);i;6\"2Y\":6\"2Z\":6\"2U\":6\"27\":6\"2P\":6\"2O\":6\"2Q\":2R:i}}k O(){2.K({Q:\"S\",j:\"c://e.9/h/f/2S.U\",T:d,R:{x:\"v\",H:5,A:5,y:5,r:5},I:\"G://2z.S.9/N/N.X?u=\"+m})}k M(){2.K({Q:\"W\",j:\"c://e.9/h/f/2g.U\",T:d,R:{x:\"v\",H:5,A:5,y:5,r:30},I:\"G://W.9/2i/2j?j=\"+m+\"&2e= 2d.9 29 \"})}k E(t){w(!l)28;w(t){2.n(1a)}13{2.n(18)}}k 19(){2a.2b(Z.2c.16,Z);2.2k(\"c://e.9/h/17/2l.2u\");$.Y(\"Y-17.X\",{2t:\"2v 2w\",j:m,2x:11})}7 12=(b.a!=b.o.a);w(12==8){7 2s=\"\"}13{7 2r=\"2n 2m 2o 2p!\\2q 31 2h 2f 2y c://e.9 2K 2J 2H 2I 2T\"}',62,188,'||player69||||case|var|true|com|location|window|http|false|oklivetv|swf|document|xplay|break|url|function|isStartedPlaying|urls|setBufferTime|parent|addEventListener|referrer|top|initialBufferTime|buffering||none|if|scaleMode|left|onJSBridge|percentHeight|flashvars|attrs|params|onBufferChange|100|https|percentWidth|clickUrl|playerId|displayAd|loading|Twitter|sharer|Facebook|displayObjectChange|id|layoutInfo|facebook|isAdvertisement|png|event|twitter|php|post|arguments||urls2|isInIFrame|else|href|streamURL|name|error|expandedBufferTime|onMediaError|bufferTime|allowFullScreen|porndig|null|allowScriptAccess|rfl3hlsr|upscale|URL|hls_error|hls_fragmentloadmaxretry|hls_manifestloadmaxretry|m3u8|hls_maxlevelcappingmode|hls_capleveltostage|chunklist_b730000|wmode|58517_20140731|embedSWF|07|swfobject|direct|000000|GrindPlayer|bgcolor|always|smil|videos|hls_warn|2014|hls_seekfromlowestlevel|bottom|hls_startfromlevel|hls_seekfromlevel|controlBarPosition|autoPlay|controlBarAutoHide|controlBarAutoHideTimeout|poster|flashlsOSMF|plugin_hls|hls_minbufferlength|hls_maxbufferlength|hls_lowbufferlength|B91F1F|hls_seekmode|hls_live_flushurlcache|gif|src|hls_info|hls_debug|verbose|encodeURIComponent|hls_startfromlowestlevel|live|tintColor|streamType|ACCURATE|javascriptCallbackFunction|hls_debug2|timeChange|return|recommends|console|log|callee|OKLiveTV|text|code|twtt|embed|intent|tweet|setMediaResourceURL|offlinee|access|Direct|not|allowed|nUse|msg|tmp|err|mp4|jwplayer|Error|url2|from|www|mediaError|getElementById|bufferingChange|ready|playing|onJavaScriptBridgeCreated|switch|into|your|insert|to|data|setScaleMode|stretch|complete|progress|advertisement|default|fbb|website|durationChange|mediaSize|paused|seeking|seeked|volumeChange||the'.split('|'),0,{})")
    val='5'
    context = js2py.EvalJs({})
    context.execute('var f = function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return\'\\w+\'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp(\'\\b\'+e(c)+\'\\b\',\'g\'),k[c])}}return p}')
    return val
def item_resolver(encoded_url):
    url = encoded_url.decode('base64')
    print url
    page = open_url(url)

    items = page.split('\n')
    list = []
    for item in items:
        if (item != ''):
			#split on ,
            data = {}
            values = item.split(',')
            data['name']=values[0].encode('base64', 'strict').replace('\n', '')
            data['url']=values[1].encode('base64', 'strict').replace('\n', '')
            list.append(data)

    return list

#print(test_js_convert(""))
print(open_url('http://oklivetv.com/blue-hustler-tv-live/'))
#print(open_url('http://oklivetv.com/xplay/xplay.php?idds=4f446b30'))
