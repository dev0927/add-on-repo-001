import re,base64


def get_src(word, txt):
    regexpstr = word + "'?[ :=]+['\"]?([^ ',\"]+)" 
    src = re.compile(regexpstr).findall(txt)[0]
    return src

def unescape(src):
    return re.sub(r'%([a-fA-F0-9]{4}|[a-fA-F0-9]{2})', lambda m: chr(int(m.group(1), 16)), src)
def encode_tuple(name, url): 
   print("name='" +  name.encode('base64', 'strict').replace('\n', '') + "'")
   print("url = '" + url.encode('base64', 'strict').replace('\n', '') + "'")
   print("config_channel(name, url)")
def config_channel(encoded_name,encoded_url):
	name = encoded_name.decode('base64')
	print(name)
	url = encoded_url.decode('base64')
	print(url)
name = 'BRAZZERS EUROPE'
url = 'http://fe-nw.svc.iptv.rt.ru/hls/CH_03_BRAZZERSTV/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'PLAYBOY'
url = 'http://fe-nw.svc.iptv.rt.ru/hls/CH_C03_PLAYBOY/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'XXL'
url = 'http://fe-nw.svc.iptv.rt.ru/hls/CH_C03_XXL/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'BLUE HUSTLER'
url = 'http://fe-nw.svc.iptv.rt.ru/hls/CH_C03_BLUEHUSTLER/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'RUSSIAN NIGHT'
url = 'http://fe-nw.svc.iptv.rt.ru/hls/CH_C03_RUSSIANNIGHT/variant.m3u8?version=2'
encode_tuple(name, url)
name ='OLALA'
url = 'http://fe-nw.svc.iptv.rt.ru/hls/CH_C03_OLALA/variant.m3u8?version=2'
encode_tuple(name, url)
name ='HOT'
url='http://4.31.30.159:9003'
encode_tuple(name, url)
name ='XXX NEW'
url='http://4.31.30.159:9005'
encode_tuple(name, url)
name ='PLAYBOY TV'
url='http://4.31.30.159:9006'
encode_tuple(name, url)
name='VIET-SEX'
url='rtmp://64.62.143.5/live/do%20not%20steal%20my-Stream2'
encode_tuple(name, url)
name ='Miami TV'
url ='http://k4.usastreams.com:1935/miamitv/smil:miamitv/playlist.m3u8'
encode_tuple(name, url)
name ='PassieXXX'
url ='rtmp://178.33.126.213/leved/ playPath=passielivestream swfUrl=https://static.rampant.tv/swf/player.swf'
encode_tuple(name, url)
name ='Private'
url ='http://178.33.126.213:1935/leved/privateCom/.m3u8'
encode_tuple(name, url)

name ='CamSoda Kitchen'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-kitchen.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Master Bedroom A'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-master-bedroom-a.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Game Room'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-gameroom.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda That 70s Room'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-that70sroom.stream/playlist.m3u8'
encode_tuple(name, url)

name = 'CamSoda Master Bedroom B'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-master-bedroom-b.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Boomboom Room'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-boomboom-room.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Shower'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-shower.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Pool'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-pool.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Keely Jones'
url='rtmp://vid1.camsoda.com:1935/cam?token=5bb689b46a4f5da3118a2a099d73b25b/?mp4:keelyjones swfUrl=http://vjs.zencdn.net/4.12/video-js.swf pageUrl=http://www.camsoda.com/keelyjones/chat'
encode_tuple(name, url)
name ='CamSoda Ryan Hart'
url='rtmp://vid1.camsoda.com:1935/cam?token=d01bee5ca46acccd71fef7bc8d119350/?mp4:ryanhart swfUrl=http://vjs.zencdn.net/4.12/video-js.swf pageUrl=http://www.camsoda.com/ryanhart/chat'
encode_tuple(name, url)
name ='CamSoda Penny Nichols'
url='rtmp://vid1.camsoda.com:1935/cam?token=c63cdb3010ab5ec86afa808a6778a7c1/?mp4:pennynichols swfUrl=http://vjs.zencdn.net/4.12/video-js.swf pageUrl=http://www.camsoda.com/pennynichols/chat'
encode_tuple(name, url)

'''


#TODO need resolver for this
name='Venus'
url ='rtmp://50.7.28.162/app playpath=16813?MTQzNjU2MjcxNDsxZTgwMDY0NjNlZDEzMGUyOTc3MjRkN2Y2ZGQyNGVjMg== swfUrl=http://cdn.shidurlive.com/player.swf pageUrl=http://www.shidurlive.com/stream/4e7a51334e5463304e7a59334e6a59314e6d55334e546468/cf49ed5ef6ea'
encode_tuple(name, url)
#TODO need resolver for this
name='Sextreme'
url ='rtmp://50.7.28.82/app playpath=16971?MTQzNjU2MzAwMjszMDA5NWI4ZmMzNmMzMmQyMjFiNDVlMWU1MzJkZjJhOA== swfUrl=http://cdn.shidurlive.com/player.swf pageUrl=http://www.shidurlive.com/stream/4e7a51334e5463304e7a59334d4463794e6a6b334e6a59784e6a51325a673d3d/65efaea19568'
encode_tuple(name, url)

'''
