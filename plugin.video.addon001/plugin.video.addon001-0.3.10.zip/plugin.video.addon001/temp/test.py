import re,base64


def get_src(word, txt):
    regexpstr = word + "'?[ :=]+['\"]?([^ ',\"]+)" 
    src = re.compile(regexpstr).findall(txt)[0]
    return src

def unescape(src):
    return re.sub(r'%([a-fA-F0-9]{4}|[a-fA-F0-9]{2})', lambda m: chr(int(m.group(1), 16)), src)
def encode_tuple(name, url): 
   print("name='" +  name.encode('base64', 'strict').replace('\n', '') + "'")
   print("url = '" + url.encode('base64', 'strict').replace('\n', '') + "'")
   print("config_channel(name, url)")
def config_channel(encoded_name,encoded_url):
	name = encoded_name.decode('base64')
	print(name)
	url = encoded_url.decode('base64')
	print(url)
name = 'BRAZZERS EUROPE'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_BRAZZERSTV/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'PLAYBOY'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_PLAYBOY/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'XXL'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_XXL/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'BLUE HUSTLER'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_BLUEHUSTLER/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'RUSSIAN NIGHT'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_RUSSIANNIGHT/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name ='OLALA'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_OLALA/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name='VIET-SEX'
url='rtmp://64.62.143.5/live/do%20not%20steal%20my-Stream2'
encode_tuple(name, url)
name ='Miami TV'
url ='http://k4.usastreams.com:1935/miamitv/smil:miamitv/playlist.m3u8'
encode_tuple(name, url)
name ='PassieXXX'
url ='rtmp://178.33.126.213/leved/ playPath=passielivestream swfUrl=https://static.rampant.tv/swf/player.swf'
encode_tuple(name, url)
name ='Private'
url ='http://178.33.126.213:1935/leved/privateCom/.m3u8'
encode_tuple(name, url)

name ='CamSoda Kitchen'
url ='http://vid1.camsoda.com:1935/videochat/camhouse-kitchen.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Master Bedroom A'
url ='http://vid1.camsoda.com:1935/videochat/camhouse-master-bedroom-a.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Game Room'
url ='http://vid1.camsoda.com:1935/videochat/camhouse-gameroom.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda That 70s Room'
url ='http://vid1.camsoda.com:1935/videochat/camhouse-that70sroom.stream/playlist.m3u8'
encode_tuple(name, url)

name = 'CamSoda Master Bedroom B'
url ='http://vid1.camsoda.com:1935/videochat/camhouse-master-bedroom-b.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Boomboom Room'
url ='http://vid1.camsoda.com:1935/videochat/camhouse-boomboom-room.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Shower'
url ='http://vid1.camsoda.com:1935/videochat/camhouse-shower.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Pool'
url ='http://vid1.camsoda.com:1935/videochat/camhouse-pool.stream/playlist.m3u8'
encode_tuple(name, url)

#TODO need resolver for this
name='Venus'
url ='rtmp://50.7.28.162/app playpath=16813?MTQzNjU2MjcxNDsxZTgwMDY0NjNlZDEzMGUyOTc3MjRkN2Y2ZGQyNGVjMg== swfUrl=http://cdn.shidurlive.com/player.swf pageUrl=http://www.shidurlive.com/stream/4e7a51334e5463304e7a59334e6a59314e6d55334e546468/cf49ed5ef6ea'
encode_tuple(name, url)
#TODO need resolver for this
name='Sextreme'
url ='rtmp://50.7.28.82/app playpath=16971?MTQzNjU2MzAwMjszMDA5NWI4ZmMzNmMzMmQyMjFiNDVlMWU1MzJkZjJhOA== swfUrl=http://cdn.shidurlive.com/player.swf pageUrl=http://www.shidurlive.com/stream/4e7a51334e5463304e7a59334d4463794e6a6b334e6a59784e6a51325a673d3d/65efaea19568'
encode_tuple(name, url)
