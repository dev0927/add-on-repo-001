import re,base64


def get_src(word, txt):
    regexpstr = word + "'?[ :=]+['\"]?([^ ',\"]+)" 
    src = re.compile(regexpstr).findall(txt)[0]
    return src

def unescape(src):
    return re.sub(r'%([a-fA-F0-9]{4}|[a-fA-F0-9]{2})', lambda m: chr(int(m.group(1), 16)), src)

url='rtmp://64.62.143.5/live/do%20not%20steal%20my-Stream2'

surl = url.encode('base64', 'strict')
print(surl)

print(surl.decode('base64'))



print('cnRtcDovLzY0LjYyLjE0My41L2xpdmUvZG8lMjBub3QlMjBzdGVhbCUyMG15LVN0cmVhbTI='.decode('base64'))
