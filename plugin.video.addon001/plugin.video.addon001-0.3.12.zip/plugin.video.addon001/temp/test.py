import re,base64


def get_src(word, txt):
    regexpstr = word + "'?[ :=]+['\"]?([^ ',\"]+)" 
    src = re.compile(regexpstr).findall(txt)[0]
    return src

def unescape(src):
    return re.sub(r'%([a-fA-F0-9]{4}|[a-fA-F0-9]{2})', lambda m: chr(int(m.group(1), 16)), src)
def encode_tuple(name, url): 
   print("name='" +  name.encode('base64', 'strict').replace('\n', '') + "'")
   print("url = '" + url.encode('base64', 'strict').replace('\n', '') + "'")
   print("config_channel(name, url)")
def config_channel(encoded_name,encoded_url):
	name = encoded_name.decode('base64')
	print(name)
	url = encoded_url.decode('base64')
	print(url)
'''	
name = 'BRAZZERS EUROPE'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_BRAZZERSTV/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'PLAYBOY'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_PLAYBOY/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'XXL'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_XXL/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'BLUE HUSTLER'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_BLUEHUSTLER/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name = 'RUSSIAN NIGHT'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_RUSSIANNIGHT/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
name ='OLALA'
url = 'http://hlsstr03-svc-iptv.ch.ma/hls/CH_OLALA/bw1500000/variant.m3u8?version=2'
encode_tuple(name, url)
'''
name ='HOT'
url='http://4.31.30.159:9003'
encode_tuple(name, url)
name ='XXX NEW'
url='http://4.31.30.159:9005'
encode_tuple(name, url)
name ='PLAYBOY TV'
url='http://4.31.30.159:9006'
encode_tuple(name, url)
name='VIET-SEX'
url='rtmp://64.62.143.5/live/do%20not%20steal%20my-Stream2'
encode_tuple(name, url)
name ='Miami TV'
url ='http://k4.usastreams.com:1935/miamitv/smil:miamitv/playlist.m3u8'
encode_tuple(name, url)
name ='PassieXXX'
url ='rtmp://178.33.126.213/leved/ playPath=passielivestream swfUrl=https://static.rampant.tv/swf/player.swf'
encode_tuple(name, url)
name ='Private'
url ='http://178.33.126.213:1935/leved/privateCom/.m3u8'
encode_tuple(name, url)

name ='CamSoda Kitchen'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-kitchen.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Master Bedroom A'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-master-bedroom-a.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Game Room'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-gameroom.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda That 70s Room'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-that70sroom.stream/playlist.m3u8'
encode_tuple(name, url)

name = 'CamSoda Master Bedroom B'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-master-bedroom-b.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Boomboom Room'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-boomboom-room.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Shower'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-shower.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Pool'
url ='http://vid1.camsoda.com:1935/camhouse/camhouse-pool.stream/playlist.m3u8'
encode_tuple(name, url)

name ='CamSoda Keely Jones'
url='rtmp://vid1.camsoda.com:1935/cam?token=5bb689b46a4f5da3118a2a099d73b25b/?mp4:keelyjones swfUrl=http://vjs.zencdn.net/4.12/video-js.swf pageUrl=http://www.camsoda.com/keelyjones/chat'
encode_tuple(name, url)
name ='CamSoda Ryan Hart'
url='rtmp://vid1.camsoda.com:1935/cam?token=d01bee5ca46acccd71fef7bc8d119350/?mp4:ryanhart swfUrl=http://vjs.zencdn.net/4.12/video-js.swf pageUrl=http://www.camsoda.com/ryanhart/chat'
encode_tuple(name, url)
name ='CamSoda Penny Nichols'
url='rtmp://vid1.camsoda.com:1935/cam?token=c63cdb3010ab5ec86afa808a6778a7c1/?mp4:pennynichols swfUrl=http://vjs.zencdn.net/4.12/video-js.swf pageUrl=http://www.camsoda.com/pennynichols/chat'
encode_tuple(name, url)

'''
name ='Hustler HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/2337.m3u8'
encode_tuple(name, url)
name ='Redlight HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/2462.m3u8'
encode_tuple(name, url)
name ='Private'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1572.m3u8'
encode_tuple(name, url)
name ='Dorcel XXX'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1573.m3u8'
encode_tuple(name, url)
name ='Hustler HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/2337.m3u8'
encode_tuple(name, url)
name ='Redlight HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/2462.m3u8'
encode_tuple(name, url)
name ='xxx-Paradise'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1572.m3u8'
encode_tuple(name, url)
name ='Dorcel XXX'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1573.m3u8'
encode_tuple(name, url)
name ='Hot Club 1 HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1000.m3u8'
encode_tuple(name, url)
name ='Hot Club 2 HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1020.m3u8'
encode_tuple(name, url)
name ='Hot Club 3 HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1021.m3u8'
encode_tuple(name, url)
name ='Hot Club 4 HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1022.m3u8'
encode_tuple(name, url)
name ='Hot Club 5 HD (BABES)'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1120.m3u8'
encode_tuple(name, url)
name ='Hot Club 6 HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1121.m3u8'
encode_tuple(name, url)
name ='Hot Club 7 HD'
url ='http://tvservice.broke-it.net:8000/live/nico/nico/1122.m3u8'


name ='IT: Hot Club 9 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4291.m3u8'
encode_tuple(name, url)
name ='IT: Hot Club 8 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4292.m3u8'
encode_tuple(name, url)
name ='IT: Hot Club 7 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4293.m3u8'
encode_tuple(name, url)
name ='IT: Hot Club 6 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4294.m3u8'
encode_tuple(name, url)
name ='IT: Hot Club 5 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4295.m3u8'
encode_tuple(name, url)
name ='IT: Hot Club 4 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4296.m3u8'
encode_tuple(name, url)
name ='IT: Hot Club 3 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4297.m3u8'
encode_tuple(name, url)
name ='IT: Hot Club 2 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4298.m3u8'
encode_tuple(name, url)
name ='IT: Hot Club 10 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4290.m3u8'
encode_tuple(name, url)
name ='IT: Hot Club 1 HD'
url ='http://portal.rapidiptv.com:8080/live/jojo/jojo/4299.m3u8'
encode_tuple(name, url)


#TODO need resolver for this
name='Venus'
url ='rtmp://50.7.28.162/app playpath=16813?MTQzNjU2MjcxNDsxZTgwMDY0NjNlZDEzMGUyOTc3MjRkN2Y2ZGQyNGVjMg== swfUrl=http://cdn.shidurlive.com/player.swf pageUrl=http://www.shidurlive.com/stream/4e7a51334e5463304e7a59334e6a59314e6d55334e546468/cf49ed5ef6ea'
encode_tuple(name, url)
#TODO need resolver for this
name='Sextreme'
url ='rtmp://50.7.28.82/app playpath=16971?MTQzNjU2MzAwMjszMDA5NWI4ZmMzNmMzMmQyMjFiNDVlMWU1MzJkZjJhOA== swfUrl=http://cdn.shidurlive.com/player.swf pageUrl=http://www.shidurlive.com/stream/4e7a51334e5463304e7a59334d4463794e6a6b334e6a59784e6a51325a673d3d/65efaea19568'
encode_tuple(name, url)

'''
